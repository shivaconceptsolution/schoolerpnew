from django.shortcuts import render
from .models import Course,Student
def index(request):
    coursedata = Course.objects.all()
    return render(request,"coursestudent/course.html",{"c":coursedata})
def stuinfo(request,id):
    studentdata = Student.objects.filter(course_id=id)
    return render(request,"coursestudent/student.html",{"st":studentdata})
def studetailinfo(request,id):
    studata = Student.objects.get(pk=id)
    return render(request,"coursestudent/detail.html",{"dt":studata})