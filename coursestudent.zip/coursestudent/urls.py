from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='index'),
     path('stuinfo/<int:id>',views.stuinfo,name='stuinfo'),
     path('studetailinfo/<int:id>',views.studetailinfo,name='studetailinfo')
]